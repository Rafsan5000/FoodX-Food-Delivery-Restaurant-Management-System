# Part 4 — Order, Payment & Reports

**Member:** Shah MD. Zunaed — 24-57769-2
**Contribution:** Order & Payment Module

## Assigned files
- `FoodDeliverySystem/Controller/PaymentController.cs`
- `FoodDeliverySystem/Controller/ReportController.cs`
- `FoodDeliverySystem/Model/Payment.cs`
- `FoodDeliverySystem/Model/Payments.cs`
- `FoodDeliverySystem/View/EmployeeDashBoard.cs`
- `FoodDeliverySystem/View/EmployeeDashBoard.Designer.cs`
- `FoodDeliverySystem/View/AdminOrders.cs`
- `FoodDeliverySystem/View/AdminOrders.Designer.cs`
- `FoodDeliverySystem/View/AdminReports.cs`
- `FoodDeliverySystem/View/AdminReports.Designer.cs`

## GitHub workflow
FoodX — GitHub Module Package

IMPORTANT:
This is a contribution/module package, not a standalone Visual Studio project.
The main project should remain on the main/base branch. Copy/commit these files
into the assigned member's branch. Do not delete the other modules from the
base branch.

Workflow:
1. Create/check out the member's branch.
2. Copy this package's FoodDeliverySystem files into the matching folders.
3. Commit with a meaningful message.
4. Push the branch.
5. Open a Pull Request to main when the module is ready.

Shared infrastructure (App.config, .sln, .csproj, Database/RestaurantDB.sql,
Database/SqlDbDataAccess.cs) stays in the base/core branch unless the team
agrees on a separate database/config owner.
