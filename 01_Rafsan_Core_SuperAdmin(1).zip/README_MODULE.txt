# Part 1 — Core System & Super Admin

**Member:** Rafsan Azad — 25-60783-1
**Contribution:** Core System & Super Admin

## Assigned files
- `FoodDeliverySystem/Common/Session.cs`
- `FoodDeliverySystem/Common/UiTheme.cs`
- `FoodDeliverySystem/Common/Validator.cs`
- `FoodDeliverySystem/Controller/LogInController.cs`
- `FoodDeliverySystem/Controller/UserController.cs`
- `FoodDeliverySystem/Controller/RestaurantController.cs`
- `FoodDeliverySystem/Controller/CategoryController.cs`
- `FoodDeliverySystem/Model/User.cs`
- `FoodDeliverySystem/Model/Users.cs`
- `FoodDeliverySystem/Model/Restaurant.cs`
- `FoodDeliverySystem/Model/Restaurants.cs`
- `FoodDeliverySystem/Model/Category.cs`
- `FoodDeliverySystem/Model/Categories.cs`
- `FoodDeliverySystem/View/LogInForm.cs`
- `FoodDeliverySystem/View/LogInForm.Designer.cs`
- `FoodDeliverySystem/View/RegisterForm.cs`
- `FoodDeliverySystem/View/RegisterForm.Designer.cs`
- `FoodDeliverySystem/View/ForgetPassword.cs`
- `FoodDeliverySystem/View/ForgetPassword.Designer.cs`
- `FoodDeliverySystem/View/SuperAdminDashBoard.cs`
- `FoodDeliverySystem/View/SuperAdminDashBoard.Designer.cs`
- `FoodDeliverySystem/View/AdminUsers.cs`
- `FoodDeliverySystem/View/AdminUsers.Designer.cs`
- `FoodDeliverySystem/View/AdminRestaurants.cs`
- `FoodDeliverySystem/View/AdminRestaurants.Designer.cs`
- `FoodDeliverySystem/View/AdminCategories.cs`
- `FoodDeliverySystem/View/AdminCategories.Designer.cs`

## GitHub workflow
FoodX — GitHub Module Package

IMPORTANT:
This is a contribution/module package, not a standalone Visual Studio project.
The main project should remain on the main/base branch. Copy/commit these files
into the assigned member's branch. Do not delete the other modules from the
base branch.

Workflow:
1. Create/check out the member's branch.
2. Copy this package's FoodDeliverySystem files into the matching folders.
3. Commit with a meaningful message.
4. Push the branch.
5. Open a Pull Request to main when the module is ready.

Shared infrastructure (App.config, .sln, .csproj, Database/RestaurantDB.sql,
Database/SqlDbDataAccess.cs) stays in the base/core branch unless the team
agrees on a separate database/config owner.
