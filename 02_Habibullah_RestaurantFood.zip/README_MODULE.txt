# Part 2 — Restaurant Admin & Food

**Member:** MD. Habibullah Tuhin — 23-50617-1
**Contribution:** Restaurant Admin & Food

## Assigned files
- `FoodDeliverySystem/Controller/FoodController.cs`
- `FoodDeliverySystem/Controller/EmployeeController.cs`
- `FoodDeliverySystem/Model/Food.cs`
- `FoodDeliverySystem/Model/Foods.cs`
- `FoodDeliverySystem/Model/Employee.cs`
- `FoodDeliverySystem/Model/Employees.cs`
- `FoodDeliverySystem/View/RestaurantDashBoard.cs`
- `FoodDeliverySystem/View/RestaurantDashBoard.Designer.cs`
- `FoodDeliverySystem/View/FoodAdminForm.cs`
- `FoodDeliverySystem/View/FoodAdminForm.Designer.cs`
- `FoodDeliverySystem/View/AdminEmployees.cs`
- `FoodDeliverySystem/View/AdminEmployees.Designer.cs`

## GitHub workflow
FoodX — GitHub Module Package

IMPORTANT:
This is a contribution/module package, not a standalone Visual Studio project.
The main project should remain on the main/base branch. Copy/commit these files
into the assigned member's branch. Do not delete the other modules from the
base branch.

Workflow:
1. Create/check out the member's branch.
2. Copy this package's FoodDeliverySystem files into the matching folders.
3. Commit with a meaningful message.
4. Push the branch.
5. Open a Pull Request to main when the module is ready.

Shared infrastructure (App.config, .sln, .csproj, Database/RestaurantDB.sql,
Database/SqlDbDataAccess.cs) stays in the base/core branch unless the team
agrees on a separate database/config owner.
